# Description: This program will allow the user to make a priority list that can be save to a text file.
# Developer: Ryan Hamersky
# Date: 11/03/2017
# Rev: New

# -----Data Section-----
import os          # --> Imports OS module. The .rename() method will be used in the program.
dicPriority = {}   # --> Defines global dictionary.
lstPriority = []   # --> Defines global list. Since list a mutable this value will be updated throughout the program.
                   # For this program it is okay that the gobal variable is mutable
                   # as it needs to change based on the user's choices.
strName = None     # --> User's name
intOption = int()  # --> User's option. Int returned from .tryexcept() method.

# -----Process Section-----
# Methods defined in the userselection class are related to selecting options from a menu.
# Modifications to the print() functions in the methods are needed
# if the new menu is not to manipulate a task priority list.
class userselection(object):
    @staticmethod
    def list(strName, lstPriority):
        '''
        Allows the user to view task and priorities.
        :param strName: User's name.
        :param lstPriority: User's current task and priorities.
        :return: Nothing is returned. Return is added just as a visual for the end of the function.
        '''
        # Checks to see if there are items in variable lstPriority using the len() function.
        if len(lstPriority) >= 1:
            print(strName + ", below is your current task priority list.\n")
            print("TASK\t\t\tPRIORTY")  # --> Header for table
            lstKey = []
            for row in lstPriority:
                strData = str(row).split(":")
                key = strData[0].strip("{'").strip("'").title()
                value = strData[1].strip().strip("'}").capitalize()
                lstKey += (key, value),
            for key in lstKey:
                print(key[0] + "\t\t" + key[1])
        # If no items are in lstPriority programs informs user to add items.
        else:
            print(strName + ", currently there are no task on your task priority list.")
            print("Please, go back to the main menu and select option 2 to add tasks. ")
        return

    @staticmethod
    def addtask(strName, lstPriority):
        '''
        Allows the user to add tasks.
        :param strName: User's name.
        :param lstPriority: User's current task and priorities.
        :return: Nothing is returned. Return is added just as a visual for the end of the function.
        '''
        while True:
            dicPriority = {}  # --> Setting dictionary to empty
            # Gathering task and priority from user.
            strTask = input(strName + ", please enter a new task. ").strip(" ").title()
            strValue = input(strName + ", please enter a priority level. "
                                       "Enter low, medium, or high. ").strip(" ").lower()
            while not (strValue == "low" or strValue == "medium" or strValue == "high"):
                strValue = input(strName + ", your choice was invalid. "
                                           "Please, enter low, medium, or high. ").strip(" ").lower()
            dicPriority[strTask] = strValue  # --> Adding a 'key' and 'value' to the dictionary.
            lstPriority += dicPriority,  # --> Adding a single row formatting as a dictionary to a table list.
            if errorhandling.addcontinue(strName) == "Yes":
                continue
            else:
                break
        return

    @staticmethod
    def removetask(strName, lstPriority):
        '''
        Allows the user to remove tasks.
        :param strName: User's name.
        :param lstPriority: User's current task and priority list.
        :return: Nothing is returned. Return is added just as a visual for the end of the function.
        '''
        # Checks to see if there are items in variable lstPriority using the len() function.
        if len(lstPriority) >= 1:
            while True:
                print(strName + ", below are your current tasks.")
                print("\nTask Number\t\t    Task")  # --> Header for table
                for row in range(len(lstPriority)):
                    strRow = str(lstPriority[row])  # --> Casting index expression into a string.
                    lstElements = strRow.split(":")  # --> Splitting task and priority
                    strTask = lstElements[0].strip("{").strip("'")  # --> Stripping for the 'key' (task).
                    print("   ", row + 1, "\t\t\t", strTask)  # --> Printing 'task number' and 'task'
                intTasknumber = int(input("\n" + "What task would you like to remove? "))
                while not (1 <= intTasknumber <= len(lstPriority)):
                    intTasknumber = int(input(strName + ", please enter 1 through " + str(len(lstPriority))))
                del lstPriority[intTasknumber - 1]  # --> Deletes list index.
                if errorhandling.removecontinue(strName) == "Yes":
                    if len(lstPriority) >= 1:
                        continue
                    else:
                        print("\n" + strName + ", currently there are no task on your task priority list.")
                        print("Please, select option 2 from the main menu add tasks. ")
                        break
                else:
                    break
        # If no items are in lstPriority programs informs user to add items.
        else:
            print(strName + ", currently there are no task on your task priority list.")
            print("Please, select option 2 from the main menu to add tasks. ")
        return

# Methods defined in the useroutputs class are related to error handling user inputs.
# Modifications to the print() functions in the methods are needed
# if the inputs are not for a task priority list.
class errorhandling(object):
    # Method removed to allow for less choices for the user. Left in program for the option to use in program if needed.
    @staticmethod
    def menureturn(strName):
        '''
        Allows the user to return to the main menu from a sub-menu.
        :param strName: User's name
        :return: Returns string data which ("Yes" or "No") is used to determine
                 if the program goes back to the main menu
        '''
        strReturn = input("\n" + strName + ", would you like to return to the main menu? "
                                           "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strReturn == "Yes" or strReturn == "No"):
            strReturn = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        return strReturn

    @staticmethod
    def addcontinue(strName):
        '''
        Allows the  user to input another task.
        :param strName: User's name
        :return: Returns string data ("Yes" or "No") which is used to determine if another task will be added.
        '''
        strContinue = input("\n" + strName + ", would you like to add another task? "
                                             "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strContinue == "Yes" or strContinue == "No"):
            strContinue = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        return strContinue

    @staticmethod
    def removecontinue(strName):
        '''
        Allows the user to remove another task.
        :param strName: User's name.
        :return: Returns string data ("Yes" or "No") which is used to determine if another task will be removed.
        '''
        strContinue = input("\n" + strName + ", would you like to remove another task? "
                                             "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strContinue == "Yes" or strContinue == "No"):
            strContinue = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        return strContinue

    @staticmethod
    def tryexcept():
        '''
        Try and except block used on User's option choice to check for integers.
        :return: Returns int data (1-5) which is used to determine what menu option will be executed.
        '''
        while True:
            try:
                intChoice = int(input(strName + ", please select an option above. "))
            except ValueError:
                print(strName + ", not a valid option. \n")
                continue
            # Verify that the user selected an option 1 through option 5.
            else:
                if 1 <= intChoice <= 5:
                    break
                else:
                    print("Integer selected is not a valid option. "
                          "Please, enter an integer and corresponds to the options given. \n")
                    continue
        return intChoice

# Methods defined in the files class are related to opening and renaming files.
# Modifications to the methods are needed if the files are not for a task priority list.
class files(object):
    @staticmethod
    def readtask(strName,dicPriority, lstPriority):
        '''
        Opens Todo.txt file and reads in tasks/priorities.
        :param strName: User's name.
        :param dicPriority: Converts data read in to dictionary rows to be used to transfer into a list table.
        :param lstPriority: User's current task and priority list.
        :return: Nothing is returned. Return is added just as a visual for the end of the function.
        '''
        # Allows Python to read the file.
        newFile = open("Todo.txt", mode="a+")

        # Moves file pointer to beginning of the file.
        newFile.seek(0, 0)

        strTitle = newFile.readline()  # --> Variable references title (first) line in text file.

        lstElements = strTitle.split("'")  # --> Variable references elements where the string was divide with '.

        strOldName = lstElements[0]  # --> Variable references the char in the splicing range.

        newFile.seek(0, 0)  # --> Moves pointer to the beginning of the file.

        if strName == strOldName:
            # Reads the rows (lines) of the file and stores them in dictionaries.
            for line in newFile:
                if len(line) is not 1:  # --> Does not allow empty lines in to the dictionary or list.
                    if strName in line:
                        del line  # --> Deletes title so it will not be added  to the list.
                    elif "Task," in line:
                        del line  # --> Deletes header so it will not be added to the list.
                    else:
                        index = line.find(",")
                        strTask = line[0:index]
                        strValue = line[index + 1:].strip("\n")
                        dicPriority[strTask] = strValue
                        lstPriority += dicPriority,
                        dicPriority = {}
                else:
                    del line
        # Deletes old data from the file that is not the user's task priority list.
        else:
            for line in newFile:
                del line
        newFile.close()
        return

    @staticmethod
    def savetask(lstPriority):
        '''
        Allows the user to save their modified task priority list.
        The program will rename the old file and save a new file if a new user ran the program.
        :param lstPriority: User's current task and priority list
        :return: Nothing is returned. Return is added just as a visual for the end of the function.
        '''
        # Open text file and assign a mode to the file.
        newFile = open("Todo.txt", mode="r")

        # Creating a new document if the user has changed. Creating a better user experience.
        newFile.seek(0, 0)  # --> This moves the pointer back to the beginning of the file.

        strTitle = newFile.readline()  # --> Variable references title (first) line in text file.

        lstElements = strTitle.split("'")  # --> Variable references elements where the string was divide with '.

        strOldName = lstElements[0]  # --> Variable references name in the title of the file.

        newFile.close()  # --> Closes open file Todo.txt.

        # Check to see if user's name has changed and renames file if needed.
        if strName != strOldName and len(strOldName) is not 0:
            # Renames Todo.txt to strOldName_Todo.txt.
            os.rename("Todo.txt", strOldName + "_Todo.txt")
            # Opens/creates new file named Todo.txt.
            newFile = open("Todo.txt", mode="w")

        else:
            # Opens/creates new file named Todo.txt.
            newFile = open("Todo.txt", mode="w")

        newFile.seek(0, 0)  # --> Moves pointer to the beginning of the file.

        # Gives a title and header to the text document.
        newFile.write(strName + "'s" + " Tasks & Priorities\n\n")
        newFile.write("Task, Priority\n")

        # Writes data to file.
        for row in lstPriority:
            strItem = str(row)  # --> Cast expression row into string data.
            lstElements = strItem.split(":")  # --> Divides string into elements at ':'
            newFile.write(lstElements[0].strip("{").strip("'") + "," +
                          lstElements[1].strip(" ").strip("}").strip("'") + "\n")
        newFile.close()
        print(strName + ", your data has been save to Todo.txt.")  # --> Notifies the user that the data has been saved.
        return

# -----Presentation Section-----

# Asking the user for their name, strips spaces, and formats their name to be capitalized.
strName = input("Hello, for a more personal experience please enter your first name. ").strip(" ").capitalize()

# Welcoming the user to the program. --> Create into a function.
print("\nWelcome, " + strName + ", to the task priority program; here you can make a task priority "
                                "list and have the ability to update your list." + "\n")

# Opens and reads file. Stores data as a table list.
files.readtask(strName,dicPriority,lstPriority)

while True:
    # User menu to update the priority list.
    print()  # --> Formatting
    print("\t\tMenu of Options\n\n"
          "\t\t1) Show current data\n\n"
          "\t\t2) Add a new item\n\n"
          "\t\t3) Remove an existing item\n\n"
          "\t\t4) Save data to file\n\n"
          "\t\t5) Exit program\n")

    # Error handles user's option choice.
    intOption = errorhandling.tryexcept()

    # User selects option 1. Displays the current task priority list.
    if intOption is 1:
        print()  # --> Formatting
        userselection.list(strName, lstPriority)
        if errorhandling.menureturn(strName) == "Yes":
            continue
        else:
            break

    # User selects option 2. Allows the user to add a task.
    elif intOption is 2:
        print()  # --> Formatting
        userselection.addtask(strName, lstPriority)
        continue

    # User selects option 3. Allows the user to remove a task from the list.
    elif intOption is 3:
        print()  # --> Formatting
        userselection.removetask(strName, lstPriority)
        continue

    # User selects option 4. Allows the user to save the task priority list.
    elif intOption is 4:
        print()  # --> Formatting
        files.savetask(lstPriority)
        continue

    # User selects option 5. Allows the user to exit the program.
    elif intOption is 5:
        print() # --> Formatting
        break

# Saves the task priority list to a text file (based on the user's name) before the program exits.
files.savetask(lstPriority)

# Notifies the user that the data has not been saved.
# Will not be used in Module 6 as assignment calls for the program to save.
# It will be kept in the code to be used at a later date.
# print("\n" + strName + ", your recent changes has not been saved to Todo.txt.\n"
                       #c"Unless option 4 was selected prior to exiting.")

# Notifies the user that the program will be closing.
print("\n" + strName + ", the program will be exiting now. Good bye!")

input("\n" + "Press enter to exit. ")
