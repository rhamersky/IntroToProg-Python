# Description: This program will allow the user to make a priority list that can be save to a text file.
# Developer: Ryan Hamersky
# Date: 10/28/2017
# Rev: New

# Asking the user for their name, strips spaces, and formats their name to be capitalized.
strName = input("Hello, for a more personal experience please enter your first name. ").strip(" ").capitalize()

# Welcoming the user to the program.
print("\nWelcome, " + strName + ", to the task priority program; here you can make a task priority "
                                "list and have the ability to update your list." + "\n")

# Allows Python to read the file.
newFile = open("Todo.txt", mode="r")

# Moves file pointer to beginning of the file.
newFile.seek(0, 0)

# Reads the rows (lines) of the file and stores them in dictionaries.
dicPriority = {}
lstPriority = []
for line in newFile:
    if len(line) != 1:  # --> Does not allow empty lines in to the dictionary or list.
        index = line.find(",")
        strTask = line[0:index]
        strValue = line[index + 1:].strip("\n")
        dicPriority[strTask] = strValue
        lstPriority += dicPriority,
        dicPriority = {}
    else:
        del line

# Removed as this is redundant lines of code the user can see what is in the file by choosing option 1.
# print()
# print(lstPriority)
# print()

strReturn = "Yes"

while strReturn != "No":
    # User menu to update the priority list.
    print()  # --> Formatting
    print("\t\tMenu of Options\n\n"
          "\t\t1) Show current data\n\n"
          "\t\t2) Add a new item\n\n"
          "\t\t3) Remove an existing item\n\n"
          "\t\t4) Save data to file\n\n"
          "\t\t5) Exit program\n")

    # User's option choice with try/except block to check for integers.
    intChoice = int()
    while True:
        try:
            intChoice = int(input(strName + ", please select an option above. "))
        except ValueError:
            print(strName + ", not a valid option. \n")
            continue
        # Verify that the user selected an option 1 through option 5.
        else:
            if 1 <= intChoice <= 5:
                break
            else:
                print("Integer selected is not a valid option. "
                      "Please, enter an integer and corresponds to the options given. \n")
                continue

    # User selects option 1. Displays the current task priority list.
    if intChoice == 1:
        print()  # --> Formatting
        print(strName + ", below is your current task priority list.\n")
        print("TASK\t\t\tPRIORTY")  # --> Header for table
        for row in lstPriority:
            strItem = str(row)  # --> Casting row as a string so string methods can be used.
            # Finding the index of the ':' so the 'key' and 'value' can be stripped from the string.
            intIndex = strItem.find(":")
            # Stripping the 'key' and 'value' from the string and formatting for the user.
            print(strItem[0:intIndex].strip("{").strip("'") + "\t\t" +
                  strItem[intIndex + 1:].strip(" ").strip("}").strip("'"))
        # Allows the user to return to the main menu
        strReturn = input("\n" + strName + ", would you like to return to the main menu? "
                                           "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strReturn == "Yes" or strReturn == "No"):
            strReturn = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        if strReturn == "Yes":
            continue
        else:
            break

    # User selects option 2. Allows the user to add a task.
    elif intChoice == 2:
        print()  # --> Formatting
        while True:
            dicPriority = {}  # --> Setting dictionary to empty
            # Gathering task and priority from user.
            strTask = input(strName + ", please enter a new task. ").strip(" ").title()
            strValue = input(strName + ", please enter a priority level. "
                                       "Enter low, medium, or high. ").strip(" ").lower()
            while not (strValue == "low" or strValue == "medium" or strValue == "high"):
                strValue = input(strName + ", your choice was invalid. "
                                           "Please, enter low, medium, or high. ").strip(" ").lower()
            dicPriority[strTask] = strValue  # --> Adding a 'key' and 'value' to the dictionary.
            lstPriority += dicPriority,  # --> Adding a single row formatting as a dictionary to a table list.
            # Allowing user to input another task.
            strContinue = input("\n" + strName + ", would you like to add another item? "
                                          "Please, enter yes or no. ").strip(" ").capitalize()
            while not (strContinue == "Yes" or strContinue == "No"):
                strContinue = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
            if strContinue == "Yes":
                continue
            else:
                break
        # Allows the user to return to the main menu
        strReturn = input("\n" + strName + ", would you like to return to the main menu? "
                                           "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strReturn == "Yes" or strReturn == "No"):
            strReturn = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        if strReturn == "Yes":
            continue
        else:
            break

    # User selects option 3. Allows the user to remove a task from the list.
    elif intChoice == 3:
        print()  # --> Formatting
        while True:
            print(strName + ", below are your current tasks.")
            print("\nTask Number\t\t    Task")  # --> Header for table
            for row in range(len(lstPriority)):
                strRow = str(lstPriority[row])  # --> Casting index expression into a string.
                intIndex = strRow.find(":")  # --> Finding the index for the ':'
                strTask = strRow[0:intIndex].strip("{").strip("'")  # --> Stripping for the 'key' (task).
                print("   ", row + 1, "\t\t\t", strTask)  # --> Printing 'task number' and 'task'
            intTasknumber = int(input("\n" + "What task would you like to remove? "))
            while not (1 <= intTasknumber <= len(lstPriority)):
                intTasknumber = int(input(strName + ", please enter 1 through" + str(len(lstPriority))))
            del lstPriority[intTasknumber - 1]  # --> Deletes list index.
            strContinue = input("\n" + strName + ", would you like to remove another item? "
                                          "Please, enter yes or no. ").strip(" ").capitalize()
            while not (strContinue == "Yes" or strContinue == "No"):
                strContinue = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
            if strContinue == "Yes":
                continue
            else:
                break
        # Allows the user to return to the main menu
        strReturn = input("\n" + strName + ", would you like to return to the main menu? "
                                           "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strReturn == "Yes" or strReturn == "No"):
            strReturn = input(strName + ", please enter yes or no. ").strip(" ").capitalize()
        if strReturn == "Yes":
            continue
        else:
            break

    # User selects option 4. Allows the user to save the task priority list.
    elif intChoice == 4:
        print()  # --> Formatting
        newFile.close()  # --> Closes file as it was in read mode.
        newFile = open("Todo.txt", mode="w")  # --> Opens file in write mode.
        for row in lstPriority:
            strItem = str(row)  # --> Cast expression row into string data.
            intIndex = strItem.find(":")  # --> Finds index of the ':'
            newFile.write(strItem[0:intIndex].strip("{").strip("'") + "," +
                          strItem[intIndex + 1:].strip(" ").strip("}").strip("'") + "\n")
        print(strName + ", your data has been save to Todo.txt.")  # --> Notifies the user that the data has been saved.
        # Allows the user to return to the main menu
        strReturn = input("\n" + strName + ", would you like to return to the main menu? "
                                           "Please, enter yes or no. ").strip(" ").capitalize()
        while not (strReturn == "Yes" or strReturn == "No"):
            strReturn = input(strName + ", please enter yes or no. ").strip(" ").capitalize
        if strReturn == "Yes":
            continue
        else:
            break

    # User selects option 5. Allows the user to exit the program.
    elif intChoice == 5:
        break

# Saving the program prior to the program closing.
newFile.close()
newFile = open("Todo.txt", mode="w")  # --> Opens file in write mode.
for row in lstPriority:
    strItem = str(row)  # --> Cast expression row into string data.
    intIndex = strItem.find(":")  # --> Finds index of the ':'
    newFile.write(strItem[0:intIndex].strip("{").strip("'") + "," +
                  strItem[intIndex + 1:].strip(" ").strip("}").strip("'") + "\n")
print("\n" + strName + ", your data has been save to Todo.txt.")  # --> Notifies the user that the data has been saved.

print("\n" + strName + ", the program will be exiting now. Good bye!")

input("\n" + "Press enter to exit. ")
